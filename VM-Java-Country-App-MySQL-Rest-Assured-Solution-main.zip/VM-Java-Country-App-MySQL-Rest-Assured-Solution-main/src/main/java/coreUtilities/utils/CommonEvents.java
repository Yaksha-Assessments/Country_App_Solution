package coreUtilities.utils;

public class CommonEvents {
	public CommonEvents() {
	}

}
